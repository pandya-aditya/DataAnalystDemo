import { InlineChart } from './shared'

// ─── Step 1: Top support drivers + deflection opportunities ──────────────────

const TICKET_CONFIG = {
  type: 'bar',
  data: {
    labels: ['WISMO', 'Returns/Refunds', 'Promo codes', 'Product Qs', 'Address change', 'Other'],
    datasets: [
      {
        label: 'Tickets this week',
        data: [412, 289, 174, 131, 88, 64],
        backgroundColor: ['#E05252', '#E8C547', '#E8C547', '#52C97A', '#52C97A', '#52C97A'],
        borderRadius: 4,
      },
    ],
  },
  options: {
    indexAxis: 'y',
    scales: {
      x: { ticks: { callback: (v) => `${v}` } },
    },
  },
}

export function CustomerResponse1({ onExpandChart }) {
  return (
    <>
      <div className="ai-text">
        <p>
          Here's the support volume breakdown for this week. WISMO ("where is my order") accounts for 36% of all tickets — and the data shows most of these could be resolved with better proactive messaging before customers ever open a ticket.
        </p>
        <p>
          Three high-leverage deflection opportunities can together reduce ticket volume by an estimated 40–50% without any new tooling.
        </p>
      </div>

      <div className="data-block">
        <InlineChart
          title="Ticket volume by contact driver (this week)"
          onExpand={() => onExpandChart?.('tickets')}
          config={TICKET_CONFIG}
        />
      </div>

      <div className="data-block">
        <div className="data-table-wrap">
          <table className="data-table" aria-label="Support drivers and deflection">
            <thead>
              <tr>
                <th>Contact driver</th>
                <th>Volume (7d)</th>
                <th>% of total</th>
                <th>Avg handle time</th>
                <th>Deflection potential</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>WISMO (order status / shipping ETA)</td>
                <td className="cell-red">412</td>
                <td className="cell-red">36%</td>
                <td>4.2 min</td>
                <td><span className="status-badge status-alert">Very High</span></td>
              </tr>
              <tr>
                <td>Returns / refund timing</td>
                <td className="cell-red">289</td>
                <td className="cell-red">25%</td>
                <td>6.8 min</td>
                <td><span className="status-badge status-alert">High</span></td>
              </tr>
              <tr>
                <td>Promo code not working / stacking</td>
                <td className="cell-amber">174</td>
                <td className="cell-amber">15%</td>
                <td>5.1 min</td>
                <td><span className="status-badge status-ok">High</span></td>
              </tr>
              <tr>
                <td>Product questions (fit, spec, availability)</td>
                <td className="cell-green">131</td>
                <td>11%</td>
                <td>7.3 min</td>
                <td><span className="status-badge status-good">Medium</span></td>
              </tr>
              <tr>
                <td>Address change requests</td>
                <td className="cell-green">88</td>
                <td>8%</td>
                <td>3.4 min</td>
                <td><span className="status-badge status-ok">Medium</span></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <div className="response-section-title">Top 3 deflection opportunities</div>
      <div className="action-cards">
        <div className="action-card visible alert">
          <div className="action-card-header">
            <span className="platform-badge">Post-purchase</span>
            <span className="action-type-pill alert">Priority</span>
            <span className="action-title">Proactive order-status messaging</span>
          </div>
          <div className="action-description">
            Send shipping confirmation with tracking link + ETA immediately after dispatch. Add a "your order is on the way" update at each carrier scan milestone. Estimated: 30–40% WISMO reduction.
          </div>
          <div className="action-btns">
            <button className="action-btn-primary">Draft email templates</button>
            <button className="action-btn-ghost">View tracking page</button>
          </div>
        </div>
        <div className="action-card visible pending">
          <div className="action-card-header">
            <span className="platform-badge">Self-serve</span>
            <span className="action-type-pill pending">This week</span>
            <span className="action-title">Returns eligibility + timeline self-serve flow</span>
          </div>
          <div className="action-description">
            Add a guided "start a return" module to the order history page with eligibility check, policy timeline, and label generation — no agent needed. Estimated: 50–60% returns ticket deflection.
          </div>
          <div className="action-btns">
            <button className="action-btn-primary">Design flow</button>
            <button className="action-btn-ghost">Add to backlog</button>
          </div>
        </div>
        <div className="action-card visible done">
          <div className="action-card-header">
            <span className="platform-badge">Help center</span>
            <span className="action-type-pill done">Quick win</span>
            <span className="action-title">Promo code troubleshooting guide + stacking rules</span>
          </div>
          <div className="action-description">
            Publish a clear "why isn't my code working?" article with decision tree and stacking exclusions. Add chatbot intent trigger for "promo" and "code" keywords. Estimated: 40% promo ticket deflection.
          </div>
          <div className="action-btns">
            <button className="action-btn-primary">Draft article</button>
            <button className="action-btn-ghost">Skip</button>
          </div>
        </div>
      </div>

      <div className="suggestions">
        <button className="suggestion-pill visible">Draft 5 support macros</button>
        <button className="suggestion-pill visible">Build automation rules</button>
        <button className="suggestion-pill visible">Show CSAT by contact driver</button>
      </div>
    </>
  )
}

// ─── Step 2: Macros + automation rules ───────────────────────────────────────

export function CustomerResponse2() {
  return (
    <>
      <div className="ai-text">
        <p>
          Here are 5 ready-to-use support macros covering the top contact drivers, plus 3 automation rules that route and respond before an agent even needs to touch the ticket.
        </p>
      </div>

      <div className="data-block">
        <div className="data-table-wrap">
          <table className="data-table" aria-label="Support macros">
            <thead>
              <tr>
                <th>#</th>
                <th>Macro name</th>
                <th>Use case</th>
                <th>Key content</th>
                <th>Est. handle time saved</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>1</td>
                <td>WISMO — standard</td>
                <td>Order status / shipping ETA</td>
                <td>ETA, tracking link, carrier contact, next steps if delayed</td>
                <td className="cell-green">−3.5 min</td>
              </tr>
              <tr>
                <td>2</td>
                <td>Returns timeline</td>
                <td>When will I get my refund?</td>
                <td>Return eligibility, processing timeline (3–5 days), confirmation email cue</td>
                <td className="cell-green">−5 min</td>
              </tr>
              <tr>
                <td>3</td>
                <td>Promo code not working</td>
                <td>Code invalid / not applying</td>
                <td>Stacking exclusions, expiry check, alternative offer if expired</td>
                <td className="cell-green">−4 min</td>
              </tr>
              <tr>
                <td>4</td>
                <td>Address change request</td>
                <td>Change shipping address</td>
                <td>Cutoff policy (pre-dispatch only), confirmation steps, "sorry if too late" escalation path</td>
                <td className="cell-green">−2.5 min</td>
              </tr>
              <tr>
                <td>5</td>
                <td>Product question — fit + spec</td>
                <td>Sizing, materials, availability</td>
                <td>Size guide link, spec highlights, "notify me" sign-up if OOS</td>
                <td className="cell-green">−5.5 min</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <div className="response-section-title">Automation rules</div>
      <div className="action-cards">
        <div className="action-card visible alert">
          <div className="action-card-header">
            <span className="platform-badge">Zendesk / Gorgias</span>
            <span className="action-type-pill alert">Rule 1</span>
            <span className="action-title">Auto-tag + route WISMO → send tracking immediately</span>
          </div>
          <div className="action-description">
            Trigger: subject or body contains "where is my order", "tracking", or "hasn't arrived". Action: auto-tag as WISMO, apply Macro 1, and close if tracking link resolves the query (bot confirms delivery in transit).
          </div>
          <div className="action-btns">
            <button className="action-btn-primary">Configure rule</button>
            <button className="action-btn-ghost">Skip</button>
          </div>
        </div>
        <div className="action-card visible pending">
          <div className="action-card-header">
            <span className="platform-badge">Zendesk / Gorgias</span>
            <span className="action-type-pill pending">Rule 2</span>
            <span className="action-title">Refund status keywords → send timeline + status link</span>
          </div>
          <div className="action-description">
            Trigger: "refund", "return status", "money back". Action: apply Macro 2 + link to self-serve returns portal. If return is already in system, auto-reply with current status.
          </div>
          <div className="action-btns">
            <button className="action-btn-primary">Configure rule</button>
            <button className="action-btn-ghost">Skip</button>
          </div>
        </div>
        <div className="action-card visible done">
          <div className="action-card-header">
            <span className="platform-badge">Zendesk / Gorgias</span>
            <span className="action-type-pill done">Rule 3</span>
            <span className="action-title">SLA escalation for high-value orders + negative sentiment</span>
          </div>
          <div className="action-description">
            Trigger: order value &gt;$150 OR sentiment score negative (NLP tag). Action: priority queue, assign to senior agent, flag for CX Manager review within 2 hours.
          </div>
          <div className="action-btns">
            <button className="action-btn-primary">Configure rule</button>
            <button className="action-btn-ghost">Skip</button>
          </div>
        </div>
      </div>

      <div className="suggestions">
        <button className="suggestion-pill visible">Create weekly CX report outline</button>
        <button className="suggestion-pill visible">A/B test macro response variants</button>
        <button className="suggestion-pill visible">Export macros to Gorgias / Zendesk</button>
      </div>
    </>
  )
}

// ─── Step 3: Weekly CX report outline ────────────────────────────────────────

export function CustomerResponse3() {
  return (
    <>
      <div className="ai-text">
        <p>
          Here's a weekly CX report outline you can share with leadership — structured to tell a story (what happened, why, what we're doing about it) rather than just dump numbers.
        </p>
      </div>

      <div className="response-section-title response-section-title-taken">This week's CX snapshot</div>
      <div className="auto-actions">
        <div className="auto-action-item">
          <div className="auto-action-text"><strong>Volume:</strong> 1,158 tickets this week (+8% WoW). WISMO and returns/refunds account for 61% of all volume. Automation deflected 142 tickets (12%) — up from 6% last week.</div>
          <div className="auto-action-time">Volume</div>
        </div>
        <div className="auto-action-item">
          <div className="auto-action-text"><strong>CSAT:</strong> 4.2 / 5.0 overall. Lowest scores on returns (3.6) and promo code tickets (3.8). Highest on product questions (4.7) — agents have strong product knowledge.</div>
          <div className="auto-action-time">CSAT</div>
        </div>
        <div className="auto-action-item">
          <div className="auto-action-text"><strong>Deflection progress:</strong> WISMO automation rule live; returns self-serve flow in dev (ETA: 5 days). Promo troubleshooter article published — early signals show a 22% click-to-close rate on related tickets.</div>
          <div className="auto-action-time">Deflection</div>
        </div>
        <div className="auto-action-item">
          <div className="auto-action-text"><strong>Product/ops signal:</strong> Returns spike on outerwear SKU cluster flagged to Merch for PDP/sizing update. Carrier delay pattern on Zone 6–8 flagged to Ops for carrier renegotiation.</div>
          <div className="auto-action-time">Signals</div>
        </div>
      </div>

      <div className="response-section-title response-section-title-permission">Action items + owners</div>
      <div className="intervention-item">
        <div className="intervention-header">
          Returns self-serve flow — dev handoff
          <span className="permission-pill">Owner: Product</span>
        </div>
        <div className="intervention-desc">
          Flow design is complete and handed off to engineering. Launch target: end of next week. Expected: 50–60% deflection of returns tickets (145+ tickets/week saved).
        </div>
        <div className="action-btns">
          <button className="action-btn-primary">View spec</button>
          <button className="action-btn-ghost">Ping dev team</button>
        </div>
      </div>

      <div className="insight-callout">
        If the 3 deflection plays land as expected, we project ticket volume down to ~650/week by next month — reducing agent hours by ~35% without headcount changes.
      </div>

      <div className="suggestions">
        <button className="suggestion-pill visible">Schedule next CX review</button>
        <button className="suggestion-pill visible">Pull CSAT verbatims for returns</button>
        <button className="suggestion-pill visible">Set up weekly report automation</button>
      </div>
    </>
  )
}
